import torch
from torch import nn

import numpy as np

# Fix random seeds
np.random.seed(1)
torch.manual_seed(1)

# Dataset
data_name = 'cora'
cites_fn = data_name + '/' + data_name + '.cites'
content_fn = data_name + '/' + data_name + '.content'

# Hyper-parameters
num_hiddens = 100
num_layers = 1
initial_lr = 1e-1
num_epochs = 10000

train_percent = 20

# Data processing
def read_cites(file_name, all_idx):
	all_edge = []
	file = open(file_name, "r")
	while True:
		content = file.readline()
		if not content:
			break
		words = content.split()
		paper_1 = all_idx.index(words[0])
		paper_2 = all_idx.index(words[1])
		edge = [paper_2, paper_1]
		all_edge.append(edge)
	file.close()

	return all_edge

def read_content(file_name):
	all_idx = []
	all_freq = []
	all_category = []
	file = open(file_name, "r")
	while True:
		content = file.readline()
		if not content:
			break
		words = content.split()
		idx = words[0]
		freq = words[1:-1]
		freq = np.array([float(f) for f in freq])
		category = words[-1]
		all_idx.append(idx)
		all_freq.append(freq)
		all_category.append(category)
	file.close()

	unique_category = list(set(all_category))
	unique_category.sort()
	num_classes = len(unique_category)

	all_label = []
	for category in all_category:
		i = unique_category.index(category)
		label = np.zeros((num_classes))
		label[i] = 1
		all_label.append(label)

	return all_idx, all_freq, all_category, all_label, unique_category, num_classes

def construct_adj(all_edge, num_nodes):
	adj = np.zeros((num_nodes, num_nodes))
	for edge in all_edge:
		adj[edge[0], edge[1]] = 1
	return torch.FloatTensor(adj)

all_idx, all_freq, all_category, all_label, unique_category, num_classes = read_content(content_fn)
all_edge = read_cites(cites_fn, all_idx)
num_nodes = len(all_idx)
num_edges = len(all_edge)

print('Number of nodes:', num_nodes)
print('Number of edges:', num_edges)
print('Number of classes:', num_classes)

adj = construct_adj(all_edge, num_nodes)

print('Adjacency size:', adj.size())

node_features = torch.cat([torch.FloatTensor(freq).unsqueeze(dim = 0) for freq in all_freq], dim = 0)

print('Node features:', node_features.size())

labels = torch.cat([torch.FloatTensor(label).unsqueeze(dim = 0) for label in all_label], dim = 0)

print('One-hot labels:', labels.size())

# Create train/test split
perm = np.random.permutation(num_nodes)
num_train = num_nodes * train_percent // 100
num_test = num_nodes - num_train

train_perm = perm[:num_train]
test_perm = perm[num_train:]

train_idx = torch.zeros((num_nodes))
train_idx[train_perm] = 1

test_idx = torch.zeros((num_nodes))
test_idx[test_perm] = 1

print('Number of training nodes:', int(torch.sum(train_idx).item()))
print('Number of testing nodes:', int(torch.sum(test_idx).item()))

# Simple Graph Neural Networks
class Simple_GNN(nn.Module):
	# Constructor
	def __init__(self, num_features, num_hiddens, num_classes, num_layers):
		super().__init__()
		self.num_features = num_features
		self.num_hiddens = num_hiddens
		self.num_classes = num_classes
		self.num_layers = num_layers

		self.fc_1 = nn.Linear(self.num_features, self.num_hiddens)

		self.layers = nn.ModuleList()
		for l in range(self.num_layers):
			self.layers.append(nn.Linear(self.num_hiddens, self.num_hiddens))

		self.fc_2 = nn.Linear(self.num_hiddens, self.num_classes)

	def forward(self, A, X):
		H = torch.sigmoid(self.fc_1(X))

		for l in range(self.num_layers):
			H = torch.sigmoid(self.layers[l](torch.matmul(A, H)))

		return self.fc_2(H)

# Create model
model = Simple_GNN(num_features = node_features.size(1), num_hiddens = num_hiddens, num_classes = num_classes, num_layers = num_layers)

# If we want this model to be in GPU then
# model = model.device('cuda')

# Optimizers: Stochastic Gradient Descent (SGD)
optim = torch.optim.SGD(model.parameters(), lr = initial_lr)

# Training process
for epoch in range(num_epochs):
	print('Epoch', epoch, '--------------------------------------')

	# Empty gradient
	optim.zero_grad()

	# Call the model
	predict = model(adj, node_features)

	# Split
	train_predict = predict[train_idx == 1]
	test_predict = predict[test_idx == 1]

	train_label = labels[train_idx == 1]
	test_label = labels[test_idx == 1]

	# Loss
	loss = torch.nn.functional.cross_entropy(train_predict, train_label, reduction = 'mean')

	# Backward
	loss.backward()

	# SGD
	optim.step()

	print('Train loss =', loss.item())

	# Compute the testing accuracy
	predict = torch.argmax(test_predict, dim = 1)
	truth = torch.argmax(test_label, dim = 1)
	test_acc = torch.sum(predict == truth) / num_test * 100
	print('Testing accuracy:', test_acc)

print('Done')
