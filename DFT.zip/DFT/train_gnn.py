import torch
from torch import nn

import scipy.io
import numpy as np

# Fix random seeds
np.random.seed(1)
torch.manual_seed(1)

# Loading data
mat = scipy.io.loadmat('qm7.mat')

X = mat['X']
R = mat['R']
Z = mat['Z']
T = mat['T']
P = mat['P']

print('X:', X.shape)
print('R:', R.shape)
print('Z:', Z.shape)
print('T:', T.shape)
print('P:', P.shape)

# Normalize the learning target
mean_T = np.mean(T)
std_T = np.std(T)
print('Mean (energy):', mean_T)
print('STD (energy):', std_T)

T = (T - mean_T) / std_T

# Hyper-parameters
num_hiddens = 100
num_layers = 3
initial_lr = 1e-1
num_epochs = 100
batch_size = 10
num_features = 4

# Simple Graph Neural Networks (GNNs)
class Simple_GNN(nn.Module):
    # Constructor
    def __init__(self, num_features, num_hiddens, num_layers):
        super().__init__()
        self.num_features = num_features
        self.num_hiddens = num_hiddens
        self.num_layers = num_layers

        self.fc_1 = nn.Linear(self.num_features, self.num_hiddens)

        self.layers = nn.ModuleList()
        for l in range(self.num_layers):
            self.layers.append(nn.Linear(self.num_hiddens, self.num_hiddens))

        self.fc_2 = nn.Linear(self.num_hiddens, 1)

    # A: Batch size x N x N
    # X: Batch size x N x D
    def forward(self, A, X):
        H = torch.sigmoid(self.fc_1(X))

        for l in range(self.num_layers):
            H = torch.sigmoid(self.layers[l](torch.matmul(A, H)))

        # H: Batch size x N x D
        H = torch.mean(H, dim = 1)

        # H: Batch size x D
        return self.fc_2(H)

# Create model
model = Simple_GNN(num_features = num_features, num_hiddens = num_hiddens, num_layers = num_layers)

# If we want this model to be in GPU then
# model = model.device('cuda')

# Optimizers: Stochastic Gradient Descent (SGD)
optim = torch.optim.SGD(model.parameters(), lr = initial_lr)

# All the trainings
num_folds = P.shape[0]
all_mae = []

for fold in range(num_folds):
	print('Fold', fold, '------------------------------------------------')

	# Training index
	training_index = np.concatenate([P[f, :] for f in range(num_folds) if f != fold])

	# Testing index
	testing_index = P[fold, :]

	num_train = training_index.shape[0]
	num_test = testing_index.shape[0]
	print('Training size:', num_train)
	print('Testing size:', num_test)

	num_train_iters = num_train // batch_size
	num_test_iters = num_test // batch_size

	# Create the training data
	X_train = torch.FloatTensor(X[training_index, :, :])
	R_train = torch.FloatTensor(R[training_index, :, :])
	Z_train = torch.FloatTensor(Z[training_index, :])
	T_train = torch.FloatTensor(T[:, training_index])

	print('X_train:', X_train.size())
	print('R_train:', R_train.size())
	print('Z_train:', Z_train.size())
	print('T_train:', T_train.size())

	# Create the testing data
	X_test = torch.FloatTensor(X[testing_index, :, :])
	R_test = torch.FloatTensor(R[testing_index, :, :])
	Z_test = torch.FloatTensor(Z[testing_index, :])
	T_test = torch.FloatTensor(T[:, testing_index])

	print('X_test:', X_test.size())
	print('R_test:', R_test.size())
	print('Z_test:', Z_test.size())
	print('T_test:', T_test.size())

	# Training for GNN
	for epoch in range(num_epochs):
		print('Epoch', epoch, ':')
		avg_loss = 0.0

		# Training
		for i in range(num_train_iters):
			indices = range(i * batch_size, (i + 1) * batch_size)
			adj = X_train[indices, :, :]
			node_features = torch.cat([R_train[indices, :, :], torch.unsqueeze(Z_train[indices, :], dim = 2)], dim = 2)
			y = T_train[:, indices]

			# Empty the gradients first
			optim.zero_grad()

			# Perform the forward pass
			predict = model(adj, node_features)

			# Loss
			loss = torch.nn.functional.mse_loss(predict, y, reduction = 'mean')

			# Perform the backward pass
			loss.backward()

			# Perform SGD update
			optim.step()

			# Summing all losses
			avg_loss += loss.item()

		avg_loss /= num_train_iters
		print("    Average training loss:", avg_loss)

	# Testing for GNN
	model.eval()

	all_y = []
	all_predict = []
	for i in range(num_test_iters):
		indices = range(i * batch_size, (i + 1) * batch_size)
		adj = X_test[indices, :, :]
		node_features = torch.cat([R_test[indices, :, :], torch.unsqueeze(Z_test[indices, :], dim = 2)], dim = 2)
		y = T_test[:, indices]

		# Empty the gradients first
		optim.zero_grad()

		# Perform the forward pass
		predict = model(adj, node_features)

		all_y.append(y.flatten())
		all_predict.append(predict.flatten().detach())

	all_y = torch.cat(all_y)
	all_predict = torch.cat(all_predict)
	
	mae = torch.mean(torch.abs(all_y - all_predict)).item() * std_T
	all_mae.append(mae)

	print('Test MAE:', mae)

print('---------------------------------------------')
all_mae = np.array(all_mae)
print('Average MAE:', np.mean(all_mae))
print('STD MAE:', np.std(all_mae))

print('Done')
