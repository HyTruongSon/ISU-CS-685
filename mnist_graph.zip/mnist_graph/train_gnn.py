import torch
from torch import nn

import numpy as np
import pickle as pkl
import matplotlib.pyplot as plt

# Fix random seeds
np.random.seed(1)
torch.manual_seed(1)

# Hyper-parameters
num_hiddens = 100
num_layers = 3
initial_lr = 1e-2
num_epochs = 10000
batch_size = 1
num_classes = 10
num_features = 3

num_train = 1000
num_test = 100

# Create a graph dataset from MNIST
num_rows = 28
num_cols = 28
num_nodes = num_rows * num_cols
DX = [-1, 1, 0, 0]
DY = [0, 0, -1, 1]
num_directions = len(DX)
assert len(DY) == num_directions

adj = np.zeros((num_nodes, num_nodes))
additional_features = np.zeros((num_nodes, 2))
for i in range(num_rows):
	for j in range(num_cols):
		index_1 = int(i * num_cols + j)
		
		# Encode the coordinates
		additional_features[index_1, 0] = i
		additional_features[index_1, 1] = j

		for d in range(num_directions):
			u = i + DX[d]
			v = j + DY[d]
			if u >= 0 and u < num_rows and v >= 0 and v < num_cols:
				index_2 = int(u * num_cols + v)
				adj[index_1, index_2] = 1
				adj[index_2, index_1] = 1

adj = torch.FloatTensor(adj)
additional_features = torch.FloatTensor(additional_features)

batch_adj = torch.cat([torch.unsqueeze(adj, dim = 0) for b in range(batch_size)], dim = 0)
batch_features = torch.cat([torch.unsqueeze(additional_features, dim = 0) for b in range(batch_size)], dim = 0)

print(batch_adj.size())

# Load the downloaded dataset
with open("mnist.pkl",'rb') as f:
    mnist = pkl.load(f)

X_train, y_train, X_test, y_test = mnist["training_images"], mnist["training_labels"], mnist["test_images"], mnist["test_labels"]

X_train = torch.FloatTensor(X_train)
y_train = torch.LongTensor(y_train)
X_test = torch.FloatTensor(X_test)
y_test = torch.LongTensor(y_test)

X_train = X_train[:num_train, :]
X_test = X_test[:num_test, :]
y_train = y_train[:num_train]
y_test = y_test[:num_test]

# Convert y into one-hot vector
def convert_y(y, num_output):
    result = torch.zeros(y.size(0), num_output)
    for i in range(y.size(0)):
        result[i, y[i]] = 1
    return result

y_train = convert_y(y_train, num_output = 10)
y_test = convert_y(y_test, num_output = 10)

print(X_train.size())
print(y_train.size())
print(X_test.size())
print(y_test.size())

print('Number of training examples:', X_train.size(0))
print('Number of testing examples:', X_test.size(0))

# Simple Graph Neural Networks (GNNs)
class Simple_GNN(nn.Module):
	# Constructor
	def __init__(self, num_features, num_hiddens, num_classes, num_layers):
		super().__init__()
		self.num_features = num_features
		self.num_hiddens = num_hiddens
		self.num_classes = num_classes
		self.num_layers = num_layers

		self.fc_1 = nn.Linear(self.num_features, self.num_hiddens)

		self.layers = nn.ModuleList()
		for l in range(self.num_layers):
			self.layers.append(nn.Linear(self.num_hiddens, self.num_hiddens))

		self.fc_2 = nn.Linear(self.num_hiddens, self.num_classes)

	# A: Batch size x N x N
	# X: Batch size x N x D
	def forward(self, A, X):
		H = torch.sigmoid(self.fc_1(X))

		for l in range(self.num_layers):
			H = torch.sigmoid(self.layers[l](torch.matmul(A, H)))

		# H: Batch size x N x D
		H = torch.mean(H, dim = 1)

		# H: Batch size x D
		return self.fc_2(H)

# Create model
model = Simple_GNN(num_features = num_features, num_hiddens = num_hiddens, num_classes = num_classes, num_layers = num_layers)

# If we want this model to be in GPU then
# model = model.device('cuda')

# Optimizers: Stochastic Gradient Descent (SGD)
optim = torch.optim.SGD(model.parameters(), lr = initial_lr)

# Training GNN
num_train_iters = X_train.size(0) // batch_size
num_test_iters = X_test.size(0) // batch_size

best_acc = 0.0
for epoch in range(num_epochs):
    print('Epoch', epoch, '-------------------------')

    avg_loss = 0.0

    # Training
    for i in range(num_train_iters):
        indices = range(i * batch_size, (i + 1) * batch_size)
        x = torch.unsqueeze(X_train[indices, :], dim = 2)
        x = torch.cat([x, batch_features], dim = 2)
        y = y_train[indices, :]

        # Empty the gradients first
        optim.zero_grad()

        # Perform the forward pass
        predict = model(batch_adj, x)

        # Loss
        # loss = nn.CrossEntropyLoss(predict, y)
        loss = torch.nn.functional.cross_entropy(predict, y, reduction = 'mean')

        # Perform the backward pass
        loss.backward()

        # Perform SGD update
        optim.step()

        # Summing all losses
        avg_loss += loss.item()

    avg_loss /= num_train_iters
    print("Average loss:", avg_loss)

    # Evaluation on the test set
    # torch.eval()

    all_predict = []
    all_truth = []

    with torch.no_grad():
        for i in range(num_test_iters):
            indices = range(i * batch_size, (i + 1) * batch_size)
            x = torch.unsqueeze(X_test[indices, :], dim = 2)
            x = torch.cat([x, batch_features], dim = 2)
            y = y_test[indices, :]

            predict = model(batch_adj, x)

            all_predict.append(torch.argmax(predict, dim = 1))
            all_truth.append(torch.argmax(y, dim = 1))

    all_predict = torch.cat(all_predict)
    all_truth = torch.cat(all_truth)

    test_acc = torch.sum(all_predict == all_truth) / X_test.shape[0] * 100
    print("Test accuracy:", test_acc)

    if test_acc > best_acc:
        print("Save model to file")
        best_acc = test_acc
        torch.save(model, "model.dat")
    # else:
    #   print("Early stop!")
    #   break

# model.load("model.dat")

print('Done')
